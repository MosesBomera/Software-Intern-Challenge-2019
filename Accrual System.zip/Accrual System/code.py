def points_accrual(id):
    """
            Calculates the number of points for a given employee as per today.
            
            Arguments
            id - <int> - The employee id
    """

# Get history.
# From a,
# What was the seniority?
# calculate the points
# points * number of months
# check tenure
# tenure * points

# Next period
# points * months
# check tenure
# tenure * points


